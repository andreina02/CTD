Luis Riofrio: Realizó la estructura semantica en HTML
Andreina Peraza: Corrigió la estructura HTML y realizó algunos cambios en ella, además elaboró la hoja de estilos e hizo la adaptabilidad en los dos dispositivos (Mobile y Desktop)

NOTA: Se utilizó la metodología mobile-first para la maquetación y diseño de la página web, tomando como punto de referencia para llevar a cabo la adaptabilidad del proyecto los siguientes anchos de pantalla:
- 480px para el diseño en dipositivos moviles 
- 1440px para el diseño en computadoras de escritorio 


